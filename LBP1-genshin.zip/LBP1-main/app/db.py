import sqlite3

DB_NAME = 'banco_notas.db'

def get_db_connection():
    """Abre uma conexão com o banco SQLite nativo e permite acessar colunas por nome."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn