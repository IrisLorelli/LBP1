from app.db import get_db_connection

class Personagem:
    def __init__(self, usuario_uid, nome, elemento, arma, raridade, id=None):
        self.id = id
        self.usuario_uid = usuario_uid
        self.nome = nome
        self.elemento = elemento
        self.arma = arma
        self.raridade = raridade

    def salvar(self):
        """Insere o personagem no banco associado ao UID do jogador."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO personagens (usuario_uid, nome, elemento, arma, raridade)
            VALUES (?, ?, ?, ?, ?)
        ''', (self.usuario_uid, self.nome, self.elemento, self.arma, self.raridade))
        conn.commit()
        conn.close()

    @classmethod
    def buscar_por_usuario(cls, usuario_uid):
        """Retorna todos os personagens salvos para um jogador específico."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, usuario_uid, nome, elemento, arma, raridade 
            FROM personagens 
            WHERE usuario_uid = ?
        ''', (usuario_uid,))
        linhas = cursor.fetchall()
        conn.close()

        personagens = []
        for linha in linhas:
            p = cls(
                id=linha['id'],
                usuario_uid=linha['usuario_uid'],
                nome=linha['nome'],
                elemento=linha['elemento'],
                arma=linha['arma'],
                raridade=linha['raridade']
            )
            personagens.append(p)
        return personagens