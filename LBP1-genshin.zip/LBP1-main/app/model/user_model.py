from app.db import get_db_connection

class Usuario:
    def __init__(self, username, uid, regiao):
        self.username = username
        self.uid = uid
        self.regiao = regiao

    def salvar(self):
        """Salva um novo usuário no banco via INSERT INTO nativo."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO usuarios (uid, username, regiao)
            VALUES (?, ?, ?)
        ''', (self.uid, self.username, self.regiao))
        conn.commit()
        conn.close()

    @classmethod
    def buscar_por_uid(cls, uid):
        """Busca usuário pelo UID usando SELECT nativo."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT username, uid, regiao FROM usuarios WHERE uid = ?', (uid,))
        linha = cursor.fetchone()
        conn.close()

        if linha:
            return cls(username=linha['username'], uid=linha['uid'], regiao=linha['regiao'])
        return None