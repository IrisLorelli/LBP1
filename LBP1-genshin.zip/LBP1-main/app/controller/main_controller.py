from flask import Blueprint, render_template, request, redirect, url_for, session
from app.model.personagem_model import Personagem
from app.utils.auth_middleware import login_required

main_bp = Blueprint('main', __name__)

@main_bp.route('/dashboard')
@login_required
def dashboard():
    uid = session['usuario_uid']
    personagens = Personagem.buscar_por_usuario(uid)
    return render_template('main/dashboard.html', personagens=personagens)

@main_bp.route('/cadastrar_personagem', methods=['POST'])
@login_required
def cadastrar_personagem():
    uid = session['usuario_uid']
    nome = request.form.get('nome')
    elemento = request.form.get('elemento')
    arma = request.form.get('arma')
    raridade = request.form.get('raridade')

    if nome and elemento and arma and raridade:
        novo = Personagem(
            usuario_uid=uid,
            nome=nome,
            elemento=elemento,
            arma=arma,
            raridade=int(raridade)
        )
        novo.salvar()

    return redirect(url_for('main.dashboard'))