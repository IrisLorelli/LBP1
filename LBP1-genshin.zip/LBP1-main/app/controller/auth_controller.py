from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app.model.user_model import Usuario

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def root():
    return redirect(url_for('auth.login'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        acao = request.form.get('acao') # 'entrar' ou 'cadastrar'
        username = request.form.get('username')
        uid = request.form.get('uid')
        regiao = request.form.get('regiao')

        if acao == 'cadastrar':
            usuario_existente = Usuario.buscar_por_uid(uid)
            if usuario_existente:
                flash('Este UID já está cadastrado no sistema!')
            else:
                novo_usuario = Usuario(username=username, uid=uid, regiao=regiao)
                novo_usuario.salvar()
                session['usuario_uid'] = novo_usuario.uid
                session['username'] = novo_usuario.username
                session['regiao'] = novo_usuario.regiao
                return redirect(url_for('main.dashboard'))

        elif acao == 'entrar':
            usuario = Usuario.buscar_por_uid(uid)
            if usuario and usuario.username == username and usuario.regiao == regiao:
                session['usuario_uid'] = usuario.uid
                session['username'] = usuario.username
                session['regiao'] = usuario.regiao
                return redirect(url_for('main.dashboard'))
            else:
                flash('Dados incorretos ou conta inexistente!')

    return render_template('auth/login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))
