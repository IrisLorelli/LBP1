import os
from flask import Flask
from iniciar_db import inicializar_banco

def create_app():
    # Define a pasta raiz de views/templates
    template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'views')
    
    app = Flask(__name__, template_folder=template_dir)
    app.secret_key = 'genshin_secret_key'

    # Garante inicialização do banco ao iniciar o servidor
    inicializar_banco()

    # Registrar Blueprints dos controllers
    from app.controller.auth_controller import auth_bp
    from app.controller.main_controller import main_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)

    return app