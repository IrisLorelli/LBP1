from functools import wraps
from flask import session, redirect, url_for

def login_required(f):
    """Garante que a rota só seja acessada se o usuário estiver logado na sessão."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_uid' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function