from app.db import get_db_connection

def inicializar_banco():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Tabela de Usuários (Viajantes)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            uid TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            regiao TEXT NOT NULL
        )
    ''')

    # Tabela de Personagens vinculada ao UID do Usuário
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS personagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_uid TEXT NOT NULL,
            nome TEXT NOT NULL,
            elemento TEXT NOT NULL,
            arma TEXT NOT NULL,
            raridade INTEGER NOT NULL,
            FOREIGN KEY (usuario_uid) REFERENCES usuarios (uid)
        )
    ''')

    conn.commit()
    conn.close()
    print("Banco de dados inicializado com sucesso!")

if __name__ == '__main__':
    inicializar_banco()